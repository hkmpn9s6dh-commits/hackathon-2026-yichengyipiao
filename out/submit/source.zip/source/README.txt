《一城一票》分层源文件
======================
01-sheet.svg     小版张 A3：每枚票是一个 <g class="stamp" data-city="..."> 图层
02-poster.svg    主视觉 A2：标题 / 主票 / 说明 / 十三印 各自成组
03-passport.svg  观赛护照 A4 横：左页 / 右页 / 中缝 各自成组
04-cards.svg     收藏卡牌：三张卡各自成组

字体已按本文件用到的字做子集并内嵌（@font-face + base64），换机器打开不会掉字。
人偶图在 assets/art/city/*.png（原图 1024×1024），替换后重跑 build.py 即可。
